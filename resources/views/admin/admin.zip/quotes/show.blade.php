@extends('admin.admin-app')
@section('title', 'Show Quotes')
@section('admin-section')
    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>Quotes</h2>
            </div>

            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Show Quotes
                            </h2>
                        </div>
                        <div class="body">

                            <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                <thead>
                                <tr>
                                    <td>S No.</td>
                                    <td>Quote</td>
                                    <td>Action</td>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($quotes as $key => $quote)
                                    <tr>
                                        <td>{{$key + 1}}</td>
                                        <td>{{$quote->quote}}</td>
                                        <td>
                                            <a href="{{url('admin/quote/'.$quote->id.'/edit')}}"><button type="button" class="btn btn-primary waves-effect">Edit</button></a>
                                            <form style="display: inline;" action="{{ url('admin/quote/'.$quote->id) }}" method="post">
                                                <input onclick="return confirm('Are you sure you want to delete this item?');" class="btn btn-danger waves-effect" type="submit" value="Delete" />
                                                @method('DELETE')
                                                {!! csrf_field() !!}
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection
