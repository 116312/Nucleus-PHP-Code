@extends('admin.admin-app')
@section('title', 'Show Quotes')
@section('admin-section')
    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>Users</h2>
            </div>

            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Show Users
                            </h2>
                        </div>
                        <div class="body">



                            <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                <thead>
                                <tr>
                                    <td>S No.</td>
                                    <td>User Name</td>
                                    <td>Mobile Number</td>
                                    <td>Email</td>
                                    <td>Plan Name</td>
                                    <td>Plan Price</td>
                                    <td>Plan Duration</td>
                                    <td>Subscription End Date</td>
                                    <td>Action</td>


                                </tr>
                                </thead>
                                <tbody>
                                @foreach($users as $key => $user)
                                    <tr>
                                        <td>{{$key + 1}}</td>
                                        <td>{{$user->subscribedUser->name}}</td>
                                        <td>{{$user->subscribedUser->phone_no}}</td>
                                        <td>{{$user->subscribedUser->email}}</td>
                                        <td>{{$user->plan_name}}</td>
                                        <td>{{$user->plan_price}}</td>
                                        <td>{{$user->plan_duration}}</td>
                                        <td style="color: white;background: {{($user->is_expire == 0 ? 'green' : 'red')}}">

                                            {{($user->is_expire == 0 ? date('d F, Y', strtotime($user->end_time)) : 'expire ' . date('d F, Y', strtotime($user->end_time)))}}</td>
                                        <td><button class="btn btn-danger un_subscribed_user" data-user-id="{{$user->id}}">Un-Subscribe</button></td>

                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection
