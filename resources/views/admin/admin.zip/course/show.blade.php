@extends('admin.admin-app')
@section('title', 'Show Course Detail')
@section('admin-section')
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>Courses</h2>
            </div>

            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Show Course
                            </h2>
                        </div>
                        <div class="body">

                            <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                <thead>
                                <tr>
                                    <td>S No.</td>
                                    <td>Course Details </td>
                                    <td>Action</td>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($courses as $key => $tag)
                                    <tr>
                                        <td>{{$key + 1}}</td>
                                        <td>{{$tag->course_name}}</td>
                                        <td>
                                            <a href="{{url('admin/course/'.$tag->id.'/edit')}}"><button type="button" class="btn btn-primary waves-effect">Edit</button></a>
                                            <form style="display: inline;" action="{{ url('admin/course/'.$tag->id) }}" method="post">
                                                <input onclick="return confirm('Are you sure you want to delete this item?');" class="btn btn-danger waves-effect" type="submit" value="Delete" />
                                                @method('DELETE')
                                                {!! csrf_field() !!}
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection
