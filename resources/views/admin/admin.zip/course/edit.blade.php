@extends('admin.admin-app')
@section('title', 'Edit Course')
@section('admin-section')

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>Course</h2>
            </div>
            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Edit Course
                            </h2>
                        </div>
                        <div class="body">
                            <form method="post" id="form_validation" action="{{url('admin/course/'.$course->id)}}">
                                @csrf
                                    @method('PUT')


                                <label for="course_name">Course Name</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" value="{{$course->course_name}}" required name="course_name" id="course_name"
                                               class="form-control">
                                    </div>
                                </div>


                                {{--<div class="form-group">--}}
                                {{--<div class="form-line">--}}
                                {{--<textarea rows="1" id="signpost_type_image_colour" name="signpost_category_image_color" class="form-control no-resize" ></textarea>--}}
                                {{--</div>--}}
                                {{--</div>--}}

                                <button type="submit" class="btn btn-primary m-t-15 waves-effect">SUBMIT</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection
