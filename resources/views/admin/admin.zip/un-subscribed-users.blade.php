@extends('admin.admin-app')
@section('title', 'Show Quotes')
@section('admin-section')
    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>Users</h2>
            </div>

            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Show Un Subscribed Users
                            </h2>
                        </div>
                        <div class="body">



                            <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                <thead>
                                <tr>
                                    <td>S No.</td>
                                    <td>User Name</td>
                                    <td>Mobile Number</td>
                                    <td>Email</td>
                                    <td>City</td>
                                    <td>Exam Preparing</td>
                                    <td>Course</td>
                                    <td>Action</td>



                                </tr>
                                </thead>
                                <tbody>
                                @foreach($mergedUser as $key => $user)
                                    <tr>
                                        <td>{{$key + 1}}</td>
                                        <td>{{$user->name}}</td>
                                        <td>{{$user->phone_no}}</td>
                                        <td>{{$user->email}}</td>
                                        <td>{{$user->city}}</td>
                                        <td>{{$user->exam_preparing}}</td>
                                        <td>{{$user->course}}</td>
                                        <td><button class="btn btn-success subscribe-user" data-user-email="{{$user->email}}" data-user-mobile="{{$user->phone_no}}" data-user-name="{{$user->name}}"  data-user-id="{{$user->id}}">Subscribe</button></td>

                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="modal fade in" id="subscrib_user_modal" tabindex="-1" role="dialog" >
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="largeModalLabel">Modal title</h4>
                </div>
                <div class="modal-body">
                <form method="post" id="form_validation" action="{{url('admin/user-subscribed')}}">
                        @csrf

                        <label for="user_name">Name</label>
                        <div class="form-group">
                            <div class="form-line">
                                <input type="text" required disabled name="user_name" id="user_name" class="form-control">
                                <input type="hidden" name="user_id" id="user_id" class="form-control">
                            </div>
                        </div>
                        <label for="user_email">Email</label>
                        <div class="form-group">
                            <div class="form-line">
                                <input type="text" required disabled name="user_email" id="user_email" class="form-control">
                            </div>
                        </div>
                        <label for="user_mobile">Mobile Number</label>
                        <div class="form-group">
                            <div class="form-line">
                                <input type="text" required disabled name="user_mobile" id="user_mobile" class="form-control">
                            </div>
                        </div>
                        <label for="plan_name">Plan Name</label>
                        <div class="form-group">
                            <div class="form-line">
                                <select class="form-control show-tick" required name="plan_name">
                                    <option value="">-- Please select --</option>
                                    <option value="Half-Year Subscription">Half-Year Subscription</option>
                                    <option value="1-Year Subscription">1-Year Subscription</option>
                                </select>
                            </div>
                        </div>

                        <label for="plan_price">Plan Price</label>
                        <div class="form-group">
                            <div class="form-line">
                                <select class="form-control show-tick" required name="plan_price">
                                    <option value="">-- Please select --</option>
                                    <option value="180">180 &#8377</option>
                                    <option value="300">300 &#8377</option>
                                </select>
                            </div>
                        </div>
                        <label for="plan_duration">Plan Duration</label>
                        <div class="form-group">
                            <div class="form-line">
                                <select class="form-control show-tick" required name="plan_duration">
                                    <option value="">-- Please select --</option>
                                    <option value="6 months">6 months</option>
                                    <option value="12 months">12 months</option>
                                </select>
                            </div>
                        </div>
                        {{--<div class="form-group">--}}
                        {{--<div class="form-line">--}}
                        {{--<textarea rows="1" id="signpost_type_image_colour" name="signpost_category_image_color" class="form-control no-resize" ></textarea>--}}
                        {{--</div>--}}
                        {{--</div>--}}

                        <button type="submit" class="btn btn-primary m-t-15 waves-effect">SUBMIT</button>
                    </form>
                </div>
                <div class="modal-footer">

                    <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CLOSE</button>
                </div>
            </div>
        </div>
    </div>
@endsection
